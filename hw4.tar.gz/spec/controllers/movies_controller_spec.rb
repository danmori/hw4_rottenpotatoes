require 'spec_helper'

describe MoviesController do
	describe 'search similar to director' do

	end
end